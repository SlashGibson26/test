package sk.machine.status;

public class StatusUtil {

    public static String createStatusMessage(int code) {
        // TODO implement
        return "";
    }

}
