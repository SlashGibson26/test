package wrapper.sk.machine.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.fail;

class MainSceneTest {

    @DisplayName("should create status message from status code")
    @Test
    void shouldCreateStatusLabelFromStatusCode() {
        fail();
    }

}
